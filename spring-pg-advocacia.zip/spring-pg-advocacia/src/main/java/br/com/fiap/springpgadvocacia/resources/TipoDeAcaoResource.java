package br.com.fiap.springpgadvocacia.resources;

public class TipoDeAcaoResource {
}
