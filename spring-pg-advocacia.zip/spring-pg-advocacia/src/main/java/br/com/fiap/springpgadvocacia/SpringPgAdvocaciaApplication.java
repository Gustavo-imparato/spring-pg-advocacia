package br.com.fiap.springpgadvocacia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPgAdvocaciaApplication {

    public static void main(String[] args) {
        SpringApplication.run( SpringPgAdvocaciaApplication.class, args );
    }

}
