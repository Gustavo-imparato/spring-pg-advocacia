package br.com.fiap.springpgadvocacia.repository;

public class TipoDeAcaoRepository {
}
