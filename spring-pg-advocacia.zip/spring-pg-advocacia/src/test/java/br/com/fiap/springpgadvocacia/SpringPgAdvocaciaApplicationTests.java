package br.com.fiap.springpgadvocacia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPgAdvocaciaApplicationTests {

    @Test
    void contextLoads() {
    }

}
